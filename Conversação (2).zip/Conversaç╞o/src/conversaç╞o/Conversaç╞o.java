/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package conversação;

import java.awt.List;


/**
 *
 * @author 081170035
 */
public class Conversação {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Pessoa p = new Pessoa("Paulo",1);
        CristianoRonaldo ronaldo = new CristianoRonaldo("Cristiano Ronaldo",1);
        p.Salute(ronaldo);
        ronaldo.Salute(p);
        ronaldo.Presentation();
        p.Presentation();
        p.Emotion("bem");
        ronaldo.Emotion("campeão da champions league");
    }
    public void StartConversation(){
        //fazer uma classe para cada tipo de pessoa
       

        Person paulo = new Person(1,"Paulo");
        Person pedro = new Person(2,"Pedro");
        Person maria = new Person(3,"Maria");
        Person carlos = new Person(4,"Carlos");
        Person neider = new Person(5,"Neide");
        Person gabriel = new Person(6,"Gabriel");
    }
    
}
